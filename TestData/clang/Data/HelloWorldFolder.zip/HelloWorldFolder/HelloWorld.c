#include <stdio.h>
    main(){
        //char str[256];
        printf("あいうえお\n");
        //printf("input>");
        //scanf("%s", str);
        //printf("%s\n", str);

        return 0;
    }
