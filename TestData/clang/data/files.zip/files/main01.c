#include <stdio.h>
#include "myh.h"


int main(void) 
{
    printf("%d\n", func1(20));
    return 0;
}
