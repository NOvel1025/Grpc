#include "myh.h"

int func1(int x) 
{
    return x * x;
}

