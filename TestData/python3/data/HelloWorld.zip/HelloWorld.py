print("あいうえお")
