<?php
 echo "あいうえお\n";
?>
